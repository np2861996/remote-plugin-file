<?php
/**
 * Index file.
 *
 * @package    Woo_Double
 */

/**
 * Silence is golden.
 */
